# La Turca Burgers Website

Dosyalar:
- index.html — ana sayfa
- styles.css — tasarım ve responsive stiller
- script.js — mobil menü ve yumuşak kaydırma
- assets/ — yüklediğin görseller ve ürün kırpımları

Kullanım:
1. ZIP'i aç.
2. index.html dosyasını tarayıcıda aç.
3. İletişim bölümündeki adres/telefon/e-posta bilgilerini kendi bilgilerinle değiştir.
4. İstersen sipariş butonlarını WhatsApp, Wolt, Foodora veya Bolt Food bağlantılarına bağla.

Not: Menü görselindeki fiyat ve ürün bilgileri tasarıma örnek olarak işlendi; yayına almadan önce doğrulaman önerilir.
